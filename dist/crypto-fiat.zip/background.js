/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/consola/dist/consola.browser.js":
/*!******************************************************!*\
  !*** ./node_modules/consola/dist/consola.browser.js ***!
  \******************************************************/
/***/ (function(module) {

!function(t,e){ true?module.exports=e():0}(this,(function(){"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t,e){for(var r=0;r<e.length;r++){var o=e[r];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}function r(t,r,o){return r&&e(t.prototype,r),o&&e(t,o),t}function o(t,e,r){return e in t?Object.defineProperty(t,e,{value:r,enumerable:!0,configurable:!0,writable:!0}):t[e]=r,t}function n(t,e){var r=Object.keys(t);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(t);e&&(o=o.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),r.push.apply(r,o)}return r}function s(t){for(var e=1;e<arguments.length;e++){var r=null!=arguments[e]?arguments[e]:{};e%2?n(Object(r),!0).forEach((function(e){o(t,e,r[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(r)):n(Object(r)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(r,e))}))}return t}function i(t){return function(t){if(Array.isArray(t))return l(t)}(t)||function(t){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(t))return Array.from(t)}(t)||a(t)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function a(t,e){if(t){if("string"==typeof t)return l(t,e);var r=Object.prototype.toString.call(t).slice(8,-1);return"Object"===r&&t.constructor&&(r=t.constructor.name),"Map"===r||"Set"===r?Array.from(t):"Arguments"===r||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)?l(t,e):void 0}}function l(t,e){(null==e||e>t.length)&&(e=t.length);for(var r=0,o=new Array(e);r<e;r++)o[r]=t[r];return o}function u(t){if("undefined"==typeof Symbol||null==t[Symbol.iterator]){if(Array.isArray(t)||(t=a(t))){var e=0,r=function(){};return{s:r,n:function(){return e>=t.length?{done:!0}:{done:!1,value:t[e++]}},e:function(t){throw t},f:r}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var o,n,s=!0,i=!1;return{s:function(){o=t[Symbol.iterator]()},n:function(){var t=o.next();return s=t.done,t},e:function(t){i=!0,n=t},f:function(){try{s||null==o.return||o.return()}finally{if(i)throw n}}}}var c={};c[c.Fatal=0]="Fatal",c[c.Error=0]="Error",c[c.Warn=1]="Warn",c[c.Log=2]="Log",c[c.Info=3]="Info",c[c.Success=3]="Success",c[c.Debug=4]="Debug",c[c.Trace=5]="Trace",c[c.Silent=-1/0]="Silent",c[c.Verbose=1/0]="Verbose";var f={silent:{level:-1},fatal:{level:c.Fatal},error:{level:c.Error},warn:{level:c.Warn},log:{level:c.Log},info:{level:c.Info},success:{level:c.Success},debug:{level:c.Debug},trace:{level:c.Trace},verbose:{level:c.Trace},ready:{level:c.Info},start:{level:c.Info}};function h(t){return e=t,"[object Object]"===Object.prototype.toString.call(e)&&(!(!t.message&&!t.args)&&!t.stack);var e}var p=!1,y=[],d=function(){function e(){var r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};for(var o in t(this,e),this._reporters=r.reporters||[],this._types=r.types||f,this.level=void 0!==r.level?r.level:3,this._defaults=r.defaults||{},this._async=void 0!==r.async?r.async:void 0,this._stdout=r.stdout,this._stderr=r.stderr,this._mockFn=r.mockFn,this._throttle=r.throttle||1e3,this._throttleMin=r.throttleMin||5,this._types){var n=s(s({type:o},this._types[o]),this._defaults);this[o]=this._wrapLogFn(n),this[o].raw=this._wrapLogFn(n,!0)}this._mockFn&&this.mockTypes(),this._lastLogSerialized=void 0,this._lastLog=void 0,this._lastLogTime=void 0,this._lastLogCount=0,this._throttleTimeout=void 0}return r(e,[{key:"create",value:function(t){return new e(Object.assign({reporters:this._reporters,level:this.level,types:this._types,defaults:this._defaults,stdout:this._stdout,stderr:this._stderr,mockFn:this._mockFn},t))}},{key:"withDefaults",value:function(t){return this.create({defaults:Object.assign({},this._defaults,t)})}},{key:"withTag",value:function(t){return this.withDefaults({tag:this._defaults.tag?this._defaults.tag+":"+t:t})}},{key:"addReporter",value:function(t){return this._reporters.push(t),this}},{key:"removeReporter",value:function(t){if(t){var e=this._reporters.indexOf(t);if(e>=0)return this._reporters.splice(e,1)}else this._reporters.splice(0);return this}},{key:"setReporters",value:function(t){return this._reporters=Array.isArray(t)?t:[t],this}},{key:"wrapAll",value:function(){this.wrapConsole(),this.wrapStd()}},{key:"restoreAll",value:function(){this.restoreConsole(),this.restoreStd()}},{key:"wrapConsole",value:function(){for(var t in this._types)console["__"+t]||(console["__"+t]=console[t]),console[t]=this[t].raw}},{key:"restoreConsole",value:function(){for(var t in this._types)console["__"+t]&&(console[t]=console["__"+t],delete console["__"+t])}},{key:"wrapStd",value:function(){this._wrapStream(this.stdout,"log"),this._wrapStream(this.stderr,"log")}},{key:"_wrapStream",value:function(t,e){var r=this;t&&(t.__write||(t.__write=t.write),t.write=function(t){r[e].raw(String(t).trim())})}},{key:"restoreStd",value:function(){this._restoreStream(this.stdout),this._restoreStream(this.stderr)}},{key:"_restoreStream",value:function(t){t&&t.__write&&(t.write=t.__write,delete t.__write)}},{key:"pauseLogs",value:function(){p=!0}},{key:"resumeLogs",value:function(){p=!1;var t,e=u(y.splice(0));try{for(e.s();!(t=e.n()).done;){var r=t.value;r[0]._logFn(r[1],r[2])}}catch(t){e.e(t)}finally{e.f()}}},{key:"mockTypes",value:function(t){if(this._mockFn=t||this._mockFn,"function"==typeof this._mockFn)for(var e in this._types)this[e]=this._mockFn(e,this._types[e])||this[e],this[e].raw=this[e]}},{key:"_wrapLogFn",value:function(t,e){var r=this;return function(){for(var o=arguments.length,n=new Array(o),s=0;s<o;s++)n[s]=arguments[s];if(!p)return r._logFn(t,n,e);y.push([r,t,n,e])}}},{key:"_logFn",value:function(t,e,r){var o=this;if(t.level>this.level)return!!this._async&&Promise.resolve(!1);var n=Object.assign({date:new Date,args:[]},t);!r&&1===e.length&&h(e[0])?Object.assign(n,e[0]):n.args=Array.from(e),n.message&&(n.args.unshift(n.message),delete n.message),n.additional&&(Array.isArray(n.additional)||(n.additional=n.additional.split("\n")),n.args.push("\n"+n.additional.join("\n")),delete n.additional),n.type="string"==typeof n.type?n.type.toLowerCase():"",n.tag="string"==typeof n.tag?n.tag.toLowerCase():"";var a=function(){var t=arguments.length>0&&void 0!==arguments[0]&&arguments[0],e=o._lastLogCount-o._throttleMin;if(o._lastLog&&e>0){var r=i(o._lastLog.args);e>1&&r.push("(repeated ".concat(e," times)")),o._log(s(s({},o._lastLog),{},{args:r})),o._lastLogCount=1}if(t){if(o._lastLog=n,o._async)return o._logAsync(n);o._log(n)}};clearTimeout(this._throttleTimeout);var l=this._lastLogTime?n.date-this._lastLogTime:0;if(this._lastLogTime=n.date,l<this._throttle)try{var u=JSON.stringify([n.type,n.tag,n.args]),c=this._lastLogSerialized===u;if(this._lastLogSerialized=u,c&&(this._lastLogCount++,this._lastLogCount>this._throttleMin))return void(this._throttleTimeout=setTimeout(a,this._throttle))}catch(t){}a(!0)}},{key:"_log",value:function(t){var e,r=u(this._reporters);try{for(r.s();!(e=r.n()).done;){e.value.log(t,{async:!1,stdout:this.stdout,stderr:this.stderr})}}catch(t){r.e(t)}finally{r.f()}}},{key:"_logAsync",value:function(t){var e=this;return Promise.all(this._reporters.map((function(r){return r.log(t,{async:!0,stdout:e.stdout,stderr:e.stderr})})))}},{key:"stdout",get:function(){return this._stdout||console._stdout}},{key:"stderr",get:function(){return this._stderr||console._stderr}}]),e}();d.prototype.add=d.prototype.addReporter,d.prototype.remove=d.prototype.removeReporter,d.prototype.clear=d.prototype.removeReporter,d.prototype.withScope=d.prototype.withTag,d.prototype.mock=d.prototype.mockTypes,d.prototype.pause=d.prototype.pauseLogs,d.prototype.resume=d.prototype.resumeLogs;var v,g=function(){function e(r){t(this,e),this.options=Object.assign({},r),this.defaultColor="#7f8c8d",this.levelColorMap={0:"#c0392b",1:"#f39c12",3:"#00BCD4"},this.typeColorMap={success:"#2ecc71"}}return r(e,[{key:"log",value:function(t){var e=t.level<1?console.__error||console.error:1===t.level&&console.warn?console.__warn||console.warn:console.__log||console.log,r="log"!==t.type?t.type:"",o=t.tag?t.tag:"",n=this.typeColorMap[t.type]||this.levelColorMap[t.level]||this.defaultColor,s="\n      background: ".concat(n,";\n      border-radius: 0.5em;\n      color: white;\n      font-weight: bold;\n      padding: 2px 0.5em;\n    "),a="%c".concat([o,r].filter(Boolean).join(":"));"string"==typeof t.args[0]?e.apply(void 0,["".concat(a,"%c ").concat(t.args[0]),s,""].concat(i(t.args.slice(1)))):e.apply(void 0,[a,s].concat(i(t.args)))}}]),e}();return"undefined"!=typeof window&&window.consola||((v=new d({reporters:[new g]})).Consola=d,v.LogLevel=c,v.BrowserReporter=g,v)}));


/***/ }),

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NUMBER_REGEX": () => (/* binding */ NUMBER_REGEX),
/* harmony export */   "CURRENCY_REGEX": () => (/* binding */ CURRENCY_REGEX),
/* harmony export */   "HTML_SPACE": () => (/* binding */ HTML_SPACE),
/* harmony export */   "PRICE_REGEX": () => (/* binding */ PRICE_REGEX),
/* harmony export */   "BINANCE_API_ROUTE": () => (/* binding */ BINANCE_API_ROUTE),
/* harmony export */   "ALARM": () => (/* binding */ ALARM)
/* harmony export */ });
// REGEX
const NUMBER_REGEX = /\d[\d\s,.]*\d+/;
const CURRENCY_REGEX =
  /[$\xA2-\xA5\u058F\u060B\u09F2\u09F3\u09FB\u0AF1\u0BF9\u0E3F\u17DB\u20A0-\u20BD\uA838\uFDFC\uFE69\uFF04\uFFE0\uFFE1\uFFE5\uFFE6]/;
const HTML_SPACE = /(\s|&nbsp;)?/;
const PRICE_REGEX = `(${CURRENCY_REGEX.source}${HTML_SPACE.source}${NUMBER_REGEX.source})|(${NUMBER_REGEX.source}${HTML_SPACE.source}${CURRENCY_REGEX.source})`;

// Routes
const BINANCE_API_ROUTE = "https://api.binance.com/api/v3/ticker/price";

// Alarms
const ALARM = {
  fetchAvgPrice: "fetchAvgPrice",
};


/***/ }),

/***/ "./src/utils.js":
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseNumber": () => (/* binding */ parseNumber),
/* harmony export */   "fetchPrices": () => (/* binding */ fetchPrices)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./src/constants.js");


const parseNumber = (textContent) => {
  const parts = textContent.replace(/[\s,]/g, ".").split(".");
  if (parts.length === 1) {
    return parseFloat(parts[0]);
  }
  let decimals = parts.pop();
  if (decimals.length === 3) {
    parts.push(decimals);
    decimals = "0";
  }
  return parseFloat(`${parts.join("")}.${decimals}`);
};

const fetchPrices = async () => {
  const response = await fetch(_constants__WEBPACK_IMPORTED_MODULE_0__.BINANCE_API_ROUTE);
  const prices = await response.json();
  return prices.reduce(
    // See: https://stackoverflow.com/a/44325124/4444546
    // eslint-disable-next-line no-return-assign,no-param-reassign,no-sequences
    (obj, item) => ((obj[item.symbol] = parseFloat(item.price)), obj),
    {}
  );
};




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!***************************!*\
  !*** ./src/background.js ***!
  \***************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var consola__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! consola */ "./node_modules/consola/dist/consola.browser.js");
/* harmony import */ var consola__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(consola__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./src/constants.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/utils.js");




// chrome APIs
async function fetchAvgPrice() {
  const prices = await (0,_utils__WEBPACK_IMPORTED_MODULE_2__.fetchPrices)();
  const { BTCUSDT: rate } = prices;
  chrome.storage.sync.set({ BTCUSDT: rate }, () => {
    consola__WEBPACK_IMPORTED_MODULE_0___default().log("Rates updated");
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === _constants__WEBPACK_IMPORTED_MODULE_1__.ALARM.fetchAvgPrice) {
    await fetchAvgPrice();
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  await fetchAvgPrice();
  chrome.alarms.create(_constants__WEBPACK_IMPORTED_MODULE_1__.ALARM.fetchAvgPrice, { periodInMinutes: 1 });
});

chrome.tabs.onUpdated.addListener((tabId) => {
  chrome.tabs.sendMessage(tabId, "refreshPrices");
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxlQUFlLEtBQW9ELG9CQUFvQixDQUF1RSxDQUFDLGtCQUFrQixhQUFhLGdCQUFnQiw4RUFBOEUsZ0JBQWdCLFlBQVksV0FBVyxLQUFLLFdBQVcsK0dBQStHLGtCQUFrQix1Q0FBdUMsa0JBQWtCLHlDQUF5QyxrREFBa0QsV0FBVyxnQkFBZ0IscUJBQXFCLGlDQUFpQyxzQ0FBc0MsNEJBQTRCLHVEQUF1RCxzQkFBc0IsU0FBUyxjQUFjLFlBQVksbUJBQW1CLEtBQUsseUNBQXlDLHlDQUF5QyxZQUFZLHFJQUFxSSxnRUFBZ0UsR0FBRyxTQUFTLGNBQWMsbUJBQW1CLGdDQUFnQyxpQkFBaUIsaUZBQWlGLHNCQUFzQiw0SkFBNEosR0FBRyxnQkFBZ0IsTUFBTSxvQ0FBb0Msb0RBQW9ELGdMQUFnTCxnQkFBZ0Isb0NBQW9DLDJCQUEyQixJQUFJLGNBQWMsU0FBUyxjQUFjLHlEQUF5RCwrQkFBK0IsdUJBQXVCLE9BQU8saUJBQWlCLG9CQUFvQixRQUFRLEVBQUUsc0JBQXNCLGVBQWUsUUFBUSxNQUFNLDZKQUE2SixrQkFBa0IsT0FBTyxhQUFhLHVCQUF1QixjQUFjLGVBQWUsa0JBQWtCLGVBQWUsU0FBUyxjQUFjLElBQUksOEJBQThCLFFBQVEsZ0JBQWdCLFNBQVMseU5BQXlOLE9BQU8sUUFBUSxTQUFTLFFBQVEsY0FBYyxRQUFRLGNBQWMsT0FBTyxhQUFhLE1BQU0sWUFBWSxPQUFPLGFBQWEsVUFBVSxnQkFBZ0IsUUFBUSxjQUFjLFFBQVEsY0FBYyxVQUFVLGNBQWMsUUFBUSxhQUFhLFFBQVEsZUFBZSxjQUFjLHFHQUFxRyxNQUFNLDJCQUEyQixhQUFhLGdFQUFnRSxpSkFBaUosOExBQThMLFdBQVcsT0FBTyxpQ0FBaUMsNkRBQTZELDhKQUE4SixhQUFhLCtCQUErQiw0QkFBNEIsaUpBQWlKLE1BQU0sRUFBRSxxQ0FBcUMsb0JBQW9CLHlCQUF5QixtQkFBbUIsR0FBRyxFQUFFLGdDQUFnQywwQkFBMEIsa0RBQWtELEdBQUcsRUFBRSxvQ0FBb0MscUNBQXFDLEVBQUUsdUNBQXVDLE1BQU0saUNBQWlDLDJDQUEyQywrQkFBK0IsYUFBYSxFQUFFLHFDQUFxQyxvREFBb0QsRUFBRSwrQkFBK0IsbUNBQW1DLEVBQUUsa0NBQWtDLHlDQUF5QyxFQUFFLG1DQUFtQywrRkFBK0YsRUFBRSxzQ0FBc0MsK0ZBQStGLEVBQUUsK0JBQStCLHlFQUF5RSxFQUFFLHNDQUFzQyxXQUFXLHVEQUF1RCwyQkFBMkIsR0FBRyxFQUFFLGtDQUFrQyxtRUFBbUUsRUFBRSx1Q0FBdUMsb0RBQW9ELEVBQUUsaUNBQWlDLE1BQU0sRUFBRSxrQ0FBa0MsS0FBSyx1QkFBdUIsSUFBSSxVQUFVLGdCQUFnQixFQUFFLGNBQWMsd0JBQXdCLFNBQVMsT0FBTyxRQUFRLFFBQVEsRUFBRSxrQ0FBa0MsOEpBQThKLEVBQUUscUNBQXFDLFdBQVcsa0JBQWtCLDhDQUE4QyxJQUFJLHNCQUFzQiw2QkFBNkIsb0JBQW9CLEVBQUUsbUNBQW1DLFdBQVcsK0RBQStELHFCQUFxQixzQkFBc0IsSUFBSSwyWEFBMlgsaUJBQWlCLCtGQUErRixvQkFBb0IseUJBQXlCLDJEQUEyRCxlQUFlLEVBQUUsT0FBTyxxQkFBcUIsTUFBTSwrQ0FBK0MsWUFBWSxvQ0FBb0MsbURBQW1ELGlEQUFpRCwwRUFBMEUsNEpBQTRKLFVBQVUsT0FBTyxFQUFFLDZCQUE2QiwyQkFBMkIsSUFBSSxVQUFVLGdCQUFnQixFQUFFLGVBQWUsK0NBQStDLEdBQUcsU0FBUyxPQUFPLFFBQVEsUUFBUSxFQUFFLGtDQUFrQyxXQUFXLG9EQUFvRCxnQkFBZ0IseUNBQXlDLEVBQUUsS0FBSyxFQUFFLDRCQUE0QixzQ0FBc0MsRUFBRSw0QkFBNEIsc0NBQXNDLEtBQUssR0FBRyxzU0FBc1MsbUJBQW1CLGNBQWMsdUNBQXVDLG9EQUFvRCxvQ0FBb0Msb0JBQW9CLG1CQUFtQixhQUFhLDRCQUE0Qiw2UkFBNlIsNkJBQTZCLHFCQUFxQiwwQkFBMEIsMkJBQTJCLHdEQUF3RCwySkFBMkosS0FBSyxHQUFHLDZEQUE2RCxrQkFBa0IsaURBQWlEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBajNSO0FBQ087QUFDQTtBQUNQO0FBQ08sOEJBQThCO0FBQzlCLHdCQUF3QixzQkFBc0IsRUFBRSxrQkFBa0IsRUFBRSxvQkFBb0IsS0FBSyxvQkFBb0IsRUFBRSxrQkFBa0IsRUFBRSxzQkFBc0I7O0FBRXBLO0FBQ087O0FBRVA7QUFDTztBQUNQO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JnRDs7QUFFaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsZUFBZSxHQUFHLFNBQVM7QUFDbEQ7O0FBRUE7QUFDQSwrQkFBK0IseURBQWlCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRW9DOzs7Ozs7O1VDMUJwQztVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7Ozs7Ozs7OztBQ044QjtBQUNNO0FBQ0U7O0FBRXRDO0FBQ0E7QUFDQSx1QkFBdUIsbURBQVc7QUFDbEMsVUFBVSxnQkFBZ0I7QUFDMUIsNEJBQTRCLGVBQWU7QUFDM0MsSUFBSSxrREFBVztBQUNmLEdBQUc7QUFDSDs7QUFFQTtBQUNBLHFCQUFxQiwyREFBbUI7QUFDeEM7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBLHVCQUF1QiwyREFBbUIsSUFBSSxvQkFBb0I7QUFDbEUsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NyeXB0by1maWF0Ly4vbm9kZV9tb2R1bGVzL2NvbnNvbGEvZGlzdC9jb25zb2xhLmJyb3dzZXIuanMiLCJ3ZWJwYWNrOi8vY3J5cHRvLWZpYXQvLi9zcmMvY29uc3RhbnRzLmpzIiwid2VicGFjazovL2NyeXB0by1maWF0Ly4vc3JjL3V0aWxzLmpzIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9jcnlwdG8tZmlhdC93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vY3J5cHRvLWZpYXQvLi9zcmMvYmFja2dyb3VuZC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIhZnVuY3Rpb24odCxlKXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz1lKCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShlKToodD10fHxzZWxmKS5jb25zb2xhPWUoKX0odGhpcywoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtmdW5jdGlvbiB0KHQsZSl7aWYoISh0IGluc3RhbmNlb2YgZSkpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKX1mdW5jdGlvbiBlKHQsZSl7Zm9yKHZhciByPTA7cjxlLmxlbmd0aDtyKyspe3ZhciBvPWVbcl07by5lbnVtZXJhYmxlPW8uZW51bWVyYWJsZXx8ITEsby5jb25maWd1cmFibGU9ITAsXCJ2YWx1ZVwiaW4gbyYmKG8ud3JpdGFibGU9ITApLE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LG8ua2V5LG8pfX1mdW5jdGlvbiByKHQscixvKXtyZXR1cm4gciYmZSh0LnByb3RvdHlwZSxyKSxvJiZlKHQsbyksdH1mdW5jdGlvbiBvKHQsZSxyKXtyZXR1cm4gZSBpbiB0P09iamVjdC5kZWZpbmVQcm9wZXJ0eSh0LGUse3ZhbHVlOnIsZW51bWVyYWJsZTohMCxjb25maWd1cmFibGU6ITAsd3JpdGFibGU6ITB9KTp0W2VdPXIsdH1mdW5jdGlvbiBuKHQsZSl7dmFyIHI9T2JqZWN0LmtleXModCk7aWYoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyl7dmFyIG89T2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyh0KTtlJiYobz1vLmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCxlKS5lbnVtZXJhYmxlfSkpKSxyLnB1c2guYXBwbHkocixvKX1yZXR1cm4gcn1mdW5jdGlvbiBzKHQpe2Zvcih2YXIgZT0xO2U8YXJndW1lbnRzLmxlbmd0aDtlKyspe3ZhciByPW51bGwhPWFyZ3VtZW50c1tlXT9hcmd1bWVudHNbZV06e307ZSUyP24oT2JqZWN0KHIpLCEwKS5mb3JFYWNoKChmdW5jdGlvbihlKXtvKHQsZSxyW2VdKX0pKTpPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycz9PYmplY3QuZGVmaW5lUHJvcGVydGllcyh0LE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHIpKTpuKE9iamVjdChyKSkuZm9yRWFjaCgoZnVuY3Rpb24oZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsZSxPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHIsZSkpfSkpfXJldHVybiB0fWZ1bmN0aW9uIGkodCl7cmV0dXJuIGZ1bmN0aW9uKHQpe2lmKEFycmF5LmlzQXJyYXkodCkpcmV0dXJuIGwodCl9KHQpfHxmdW5jdGlvbih0KXtpZihcInVuZGVmaW5lZFwiIT10eXBlb2YgU3ltYm9sJiZTeW1ib2wuaXRlcmF0b3IgaW4gT2JqZWN0KHQpKXJldHVybiBBcnJheS5mcm9tKHQpfSh0KXx8YSh0KXx8ZnVuY3Rpb24oKXt0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCBhdHRlbXB0IHRvIHNwcmVhZCBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKX0oKX1mdW5jdGlvbiBhKHQsZSl7aWYodCl7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpcmV0dXJuIGwodCxlKTt2YXIgcj1PYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodCkuc2xpY2UoOCwtMSk7cmV0dXJuXCJPYmplY3RcIj09PXImJnQuY29uc3RydWN0b3ImJihyPXQuY29uc3RydWN0b3IubmFtZSksXCJNYXBcIj09PXJ8fFwiU2V0XCI9PT1yP0FycmF5LmZyb20odCk6XCJBcmd1bWVudHNcIj09PXJ8fC9eKD86VWl8SSludCg/Ojh8MTZ8MzIpKD86Q2xhbXBlZCk/QXJyYXkkLy50ZXN0KHIpP2wodCxlKTp2b2lkIDB9fWZ1bmN0aW9uIGwodCxlKXsobnVsbD09ZXx8ZT50Lmxlbmd0aCkmJihlPXQubGVuZ3RoKTtmb3IodmFyIHI9MCxvPW5ldyBBcnJheShlKTtyPGU7cisrKW9bcl09dFtyXTtyZXR1cm4gb31mdW5jdGlvbiB1KHQpe2lmKFwidW5kZWZpbmVkXCI9PXR5cGVvZiBTeW1ib2x8fG51bGw9PXRbU3ltYm9sLml0ZXJhdG9yXSl7aWYoQXJyYXkuaXNBcnJheSh0KXx8KHQ9YSh0KSkpe3ZhciBlPTAscj1mdW5jdGlvbigpe307cmV0dXJue3M6cixuOmZ1bmN0aW9uKCl7cmV0dXJuIGU+PXQubGVuZ3RoP3tkb25lOiEwfTp7ZG9uZTohMSx2YWx1ZTp0W2UrK119fSxlOmZ1bmN0aW9uKHQpe3Rocm93IHR9LGY6cn19dGhyb3cgbmV3IFR5cGVFcnJvcihcIkludmFsaWQgYXR0ZW1wdCB0byBpdGVyYXRlIG5vbi1pdGVyYWJsZSBpbnN0YW5jZS5cXG5JbiBvcmRlciB0byBiZSBpdGVyYWJsZSwgbm9uLWFycmF5IG9iamVjdHMgbXVzdCBoYXZlIGEgW1N5bWJvbC5pdGVyYXRvcl0oKSBtZXRob2QuXCIpfXZhciBvLG4scz0hMCxpPSExO3JldHVybntzOmZ1bmN0aW9uKCl7bz10W1N5bWJvbC5pdGVyYXRvcl0oKX0sbjpmdW5jdGlvbigpe3ZhciB0PW8ubmV4dCgpO3JldHVybiBzPXQuZG9uZSx0fSxlOmZ1bmN0aW9uKHQpe2k9ITAsbj10fSxmOmZ1bmN0aW9uKCl7dHJ5e3N8fG51bGw9PW8ucmV0dXJufHxvLnJldHVybigpfWZpbmFsbHl7aWYoaSl0aHJvdyBufX19fXZhciBjPXt9O2NbYy5GYXRhbD0wXT1cIkZhdGFsXCIsY1tjLkVycm9yPTBdPVwiRXJyb3JcIixjW2MuV2Fybj0xXT1cIldhcm5cIixjW2MuTG9nPTJdPVwiTG9nXCIsY1tjLkluZm89M109XCJJbmZvXCIsY1tjLlN1Y2Nlc3M9M109XCJTdWNjZXNzXCIsY1tjLkRlYnVnPTRdPVwiRGVidWdcIixjW2MuVHJhY2U9NV09XCJUcmFjZVwiLGNbYy5TaWxlbnQ9LTEvMF09XCJTaWxlbnRcIixjW2MuVmVyYm9zZT0xLzBdPVwiVmVyYm9zZVwiO3ZhciBmPXtzaWxlbnQ6e2xldmVsOi0xfSxmYXRhbDp7bGV2ZWw6Yy5GYXRhbH0sZXJyb3I6e2xldmVsOmMuRXJyb3J9LHdhcm46e2xldmVsOmMuV2Fybn0sbG9nOntsZXZlbDpjLkxvZ30saW5mbzp7bGV2ZWw6Yy5JbmZvfSxzdWNjZXNzOntsZXZlbDpjLlN1Y2Nlc3N9LGRlYnVnOntsZXZlbDpjLkRlYnVnfSx0cmFjZTp7bGV2ZWw6Yy5UcmFjZX0sdmVyYm9zZTp7bGV2ZWw6Yy5UcmFjZX0scmVhZHk6e2xldmVsOmMuSW5mb30sc3RhcnQ6e2xldmVsOmMuSW5mb319O2Z1bmN0aW9uIGgodCl7cmV0dXJuIGU9dCxcIltvYmplY3QgT2JqZWN0XVwiPT09T2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGUpJiYoISghdC5tZXNzYWdlJiYhdC5hcmdzKSYmIXQuc3RhY2spO3ZhciBlfXZhciBwPSExLHk9W10sZD1mdW5jdGlvbigpe2Z1bmN0aW9uIGUoKXt2YXIgcj1hcmd1bWVudHMubGVuZ3RoPjAmJnZvaWQgMCE9PWFyZ3VtZW50c1swXT9hcmd1bWVudHNbMF06e307Zm9yKHZhciBvIGluIHQodGhpcyxlKSx0aGlzLl9yZXBvcnRlcnM9ci5yZXBvcnRlcnN8fFtdLHRoaXMuX3R5cGVzPXIudHlwZXN8fGYsdGhpcy5sZXZlbD12b2lkIDAhPT1yLmxldmVsP3IubGV2ZWw6Myx0aGlzLl9kZWZhdWx0cz1yLmRlZmF1bHRzfHx7fSx0aGlzLl9hc3luYz12b2lkIDAhPT1yLmFzeW5jP3IuYXN5bmM6dm9pZCAwLHRoaXMuX3N0ZG91dD1yLnN0ZG91dCx0aGlzLl9zdGRlcnI9ci5zdGRlcnIsdGhpcy5fbW9ja0ZuPXIubW9ja0ZuLHRoaXMuX3Rocm90dGxlPXIudGhyb3R0bGV8fDFlMyx0aGlzLl90aHJvdHRsZU1pbj1yLnRocm90dGxlTWlufHw1LHRoaXMuX3R5cGVzKXt2YXIgbj1zKHMoe3R5cGU6b30sdGhpcy5fdHlwZXNbb10pLHRoaXMuX2RlZmF1bHRzKTt0aGlzW29dPXRoaXMuX3dyYXBMb2dGbihuKSx0aGlzW29dLnJhdz10aGlzLl93cmFwTG9nRm4obiwhMCl9dGhpcy5fbW9ja0ZuJiZ0aGlzLm1vY2tUeXBlcygpLHRoaXMuX2xhc3RMb2dTZXJpYWxpemVkPXZvaWQgMCx0aGlzLl9sYXN0TG9nPXZvaWQgMCx0aGlzLl9sYXN0TG9nVGltZT12b2lkIDAsdGhpcy5fbGFzdExvZ0NvdW50PTAsdGhpcy5fdGhyb3R0bGVUaW1lb3V0PXZvaWQgMH1yZXR1cm4gcihlLFt7a2V5OlwiY3JlYXRlXCIsdmFsdWU6ZnVuY3Rpb24odCl7cmV0dXJuIG5ldyBlKE9iamVjdC5hc3NpZ24oe3JlcG9ydGVyczp0aGlzLl9yZXBvcnRlcnMsbGV2ZWw6dGhpcy5sZXZlbCx0eXBlczp0aGlzLl90eXBlcyxkZWZhdWx0czp0aGlzLl9kZWZhdWx0cyxzdGRvdXQ6dGhpcy5fc3Rkb3V0LHN0ZGVycjp0aGlzLl9zdGRlcnIsbW9ja0ZuOnRoaXMuX21vY2tGbn0sdCkpfX0se2tleTpcIndpdGhEZWZhdWx0c1wiLHZhbHVlOmZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLmNyZWF0ZSh7ZGVmYXVsdHM6T2JqZWN0LmFzc2lnbih7fSx0aGlzLl9kZWZhdWx0cyx0KX0pfX0se2tleTpcIndpdGhUYWdcIix2YWx1ZTpmdW5jdGlvbih0KXtyZXR1cm4gdGhpcy53aXRoRGVmYXVsdHMoe3RhZzp0aGlzLl9kZWZhdWx0cy50YWc/dGhpcy5fZGVmYXVsdHMudGFnK1wiOlwiK3Q6dH0pfX0se2tleTpcImFkZFJlcG9ydGVyXCIsdmFsdWU6ZnVuY3Rpb24odCl7cmV0dXJuIHRoaXMuX3JlcG9ydGVycy5wdXNoKHQpLHRoaXN9fSx7a2V5OlwicmVtb3ZlUmVwb3J0ZXJcIix2YWx1ZTpmdW5jdGlvbih0KXtpZih0KXt2YXIgZT10aGlzLl9yZXBvcnRlcnMuaW5kZXhPZih0KTtpZihlPj0wKXJldHVybiB0aGlzLl9yZXBvcnRlcnMuc3BsaWNlKGUsMSl9ZWxzZSB0aGlzLl9yZXBvcnRlcnMuc3BsaWNlKDApO3JldHVybiB0aGlzfX0se2tleTpcInNldFJlcG9ydGVyc1wiLHZhbHVlOmZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLl9yZXBvcnRlcnM9QXJyYXkuaXNBcnJheSh0KT90Olt0XSx0aGlzfX0se2tleTpcIndyYXBBbGxcIix2YWx1ZTpmdW5jdGlvbigpe3RoaXMud3JhcENvbnNvbGUoKSx0aGlzLndyYXBTdGQoKX19LHtrZXk6XCJyZXN0b3JlQWxsXCIsdmFsdWU6ZnVuY3Rpb24oKXt0aGlzLnJlc3RvcmVDb25zb2xlKCksdGhpcy5yZXN0b3JlU3RkKCl9fSx7a2V5Olwid3JhcENvbnNvbGVcIix2YWx1ZTpmdW5jdGlvbigpe2Zvcih2YXIgdCBpbiB0aGlzLl90eXBlcyljb25zb2xlW1wiX19cIit0XXx8KGNvbnNvbGVbXCJfX1wiK3RdPWNvbnNvbGVbdF0pLGNvbnNvbGVbdF09dGhpc1t0XS5yYXd9fSx7a2V5OlwicmVzdG9yZUNvbnNvbGVcIix2YWx1ZTpmdW5jdGlvbigpe2Zvcih2YXIgdCBpbiB0aGlzLl90eXBlcyljb25zb2xlW1wiX19cIit0XSYmKGNvbnNvbGVbdF09Y29uc29sZVtcIl9fXCIrdF0sZGVsZXRlIGNvbnNvbGVbXCJfX1wiK3RdKX19LHtrZXk6XCJ3cmFwU3RkXCIsdmFsdWU6ZnVuY3Rpb24oKXt0aGlzLl93cmFwU3RyZWFtKHRoaXMuc3Rkb3V0LFwibG9nXCIpLHRoaXMuX3dyYXBTdHJlYW0odGhpcy5zdGRlcnIsXCJsb2dcIil9fSx7a2V5OlwiX3dyYXBTdHJlYW1cIix2YWx1ZTpmdW5jdGlvbih0LGUpe3ZhciByPXRoaXM7dCYmKHQuX193cml0ZXx8KHQuX193cml0ZT10LndyaXRlKSx0LndyaXRlPWZ1bmN0aW9uKHQpe3JbZV0ucmF3KFN0cmluZyh0KS50cmltKCkpfSl9fSx7a2V5OlwicmVzdG9yZVN0ZFwiLHZhbHVlOmZ1bmN0aW9uKCl7dGhpcy5fcmVzdG9yZVN0cmVhbSh0aGlzLnN0ZG91dCksdGhpcy5fcmVzdG9yZVN0cmVhbSh0aGlzLnN0ZGVycil9fSx7a2V5OlwiX3Jlc3RvcmVTdHJlYW1cIix2YWx1ZTpmdW5jdGlvbih0KXt0JiZ0Ll9fd3JpdGUmJih0LndyaXRlPXQuX193cml0ZSxkZWxldGUgdC5fX3dyaXRlKX19LHtrZXk6XCJwYXVzZUxvZ3NcIix2YWx1ZTpmdW5jdGlvbigpe3A9ITB9fSx7a2V5OlwicmVzdW1lTG9nc1wiLHZhbHVlOmZ1bmN0aW9uKCl7cD0hMTt2YXIgdCxlPXUoeS5zcGxpY2UoMCkpO3RyeXtmb3IoZS5zKCk7ISh0PWUubigpKS5kb25lOyl7dmFyIHI9dC52YWx1ZTtyWzBdLl9sb2dGbihyWzFdLHJbMl0pfX1jYXRjaCh0KXtlLmUodCl9ZmluYWxseXtlLmYoKX19fSx7a2V5OlwibW9ja1R5cGVzXCIsdmFsdWU6ZnVuY3Rpb24odCl7aWYodGhpcy5fbW9ja0ZuPXR8fHRoaXMuX21vY2tGbixcImZ1bmN0aW9uXCI9PXR5cGVvZiB0aGlzLl9tb2NrRm4pZm9yKHZhciBlIGluIHRoaXMuX3R5cGVzKXRoaXNbZV09dGhpcy5fbW9ja0ZuKGUsdGhpcy5fdHlwZXNbZV0pfHx0aGlzW2VdLHRoaXNbZV0ucmF3PXRoaXNbZV19fSx7a2V5OlwiX3dyYXBMb2dGblwiLHZhbHVlOmZ1bmN0aW9uKHQsZSl7dmFyIHI9dGhpcztyZXR1cm4gZnVuY3Rpb24oKXtmb3IodmFyIG89YXJndW1lbnRzLmxlbmd0aCxuPW5ldyBBcnJheShvKSxzPTA7czxvO3MrKyluW3NdPWFyZ3VtZW50c1tzXTtpZighcClyZXR1cm4gci5fbG9nRm4odCxuLGUpO3kucHVzaChbcix0LG4sZV0pfX19LHtrZXk6XCJfbG9nRm5cIix2YWx1ZTpmdW5jdGlvbih0LGUscil7dmFyIG89dGhpcztpZih0LmxldmVsPnRoaXMubGV2ZWwpcmV0dXJuISF0aGlzLl9hc3luYyYmUHJvbWlzZS5yZXNvbHZlKCExKTt2YXIgbj1PYmplY3QuYXNzaWduKHtkYXRlOm5ldyBEYXRlLGFyZ3M6W119LHQpOyFyJiYxPT09ZS5sZW5ndGgmJmgoZVswXSk/T2JqZWN0LmFzc2lnbihuLGVbMF0pOm4uYXJncz1BcnJheS5mcm9tKGUpLG4ubWVzc2FnZSYmKG4uYXJncy51bnNoaWZ0KG4ubWVzc2FnZSksZGVsZXRlIG4ubWVzc2FnZSksbi5hZGRpdGlvbmFsJiYoQXJyYXkuaXNBcnJheShuLmFkZGl0aW9uYWwpfHwobi5hZGRpdGlvbmFsPW4uYWRkaXRpb25hbC5zcGxpdChcIlxcblwiKSksbi5hcmdzLnB1c2goXCJcXG5cIituLmFkZGl0aW9uYWwuam9pbihcIlxcblwiKSksZGVsZXRlIG4uYWRkaXRpb25hbCksbi50eXBlPVwic3RyaW5nXCI9PXR5cGVvZiBuLnR5cGU/bi50eXBlLnRvTG93ZXJDYXNlKCk6XCJcIixuLnRhZz1cInN0cmluZ1wiPT10eXBlb2Ygbi50YWc/bi50YWcudG9Mb3dlckNhc2UoKTpcIlwiO3ZhciBhPWZ1bmN0aW9uKCl7dmFyIHQ9YXJndW1lbnRzLmxlbmd0aD4wJiZ2b2lkIDAhPT1hcmd1bWVudHNbMF0mJmFyZ3VtZW50c1swXSxlPW8uX2xhc3RMb2dDb3VudC1vLl90aHJvdHRsZU1pbjtpZihvLl9sYXN0TG9nJiZlPjApe3ZhciByPWkoby5fbGFzdExvZy5hcmdzKTtlPjEmJnIucHVzaChcIihyZXBlYXRlZCBcIi5jb25jYXQoZSxcIiB0aW1lcylcIikpLG8uX2xvZyhzKHMoe30sby5fbGFzdExvZykse30se2FyZ3M6cn0pKSxvLl9sYXN0TG9nQ291bnQ9MX1pZih0KXtpZihvLl9sYXN0TG9nPW4sby5fYXN5bmMpcmV0dXJuIG8uX2xvZ0FzeW5jKG4pO28uX2xvZyhuKX19O2NsZWFyVGltZW91dCh0aGlzLl90aHJvdHRsZVRpbWVvdXQpO3ZhciBsPXRoaXMuX2xhc3RMb2dUaW1lP24uZGF0ZS10aGlzLl9sYXN0TG9nVGltZTowO2lmKHRoaXMuX2xhc3RMb2dUaW1lPW4uZGF0ZSxsPHRoaXMuX3Rocm90dGxlKXRyeXt2YXIgdT1KU09OLnN0cmluZ2lmeShbbi50eXBlLG4udGFnLG4uYXJnc10pLGM9dGhpcy5fbGFzdExvZ1NlcmlhbGl6ZWQ9PT11O2lmKHRoaXMuX2xhc3RMb2dTZXJpYWxpemVkPXUsYyYmKHRoaXMuX2xhc3RMb2dDb3VudCsrLHRoaXMuX2xhc3RMb2dDb3VudD50aGlzLl90aHJvdHRsZU1pbikpcmV0dXJuIHZvaWQodGhpcy5fdGhyb3R0bGVUaW1lb3V0PXNldFRpbWVvdXQoYSx0aGlzLl90aHJvdHRsZSkpfWNhdGNoKHQpe31hKCEwKX19LHtrZXk6XCJfbG9nXCIsdmFsdWU6ZnVuY3Rpb24odCl7dmFyIGUscj11KHRoaXMuX3JlcG9ydGVycyk7dHJ5e2ZvcihyLnMoKTshKGU9ci5uKCkpLmRvbmU7KXtlLnZhbHVlLmxvZyh0LHthc3luYzohMSxzdGRvdXQ6dGhpcy5zdGRvdXQsc3RkZXJyOnRoaXMuc3RkZXJyfSl9fWNhdGNoKHQpe3IuZSh0KX1maW5hbGx5e3IuZigpfX19LHtrZXk6XCJfbG9nQXN5bmNcIix2YWx1ZTpmdW5jdGlvbih0KXt2YXIgZT10aGlzO3JldHVybiBQcm9taXNlLmFsbCh0aGlzLl9yZXBvcnRlcnMubWFwKChmdW5jdGlvbihyKXtyZXR1cm4gci5sb2codCx7YXN5bmM6ITAsc3Rkb3V0OmUuc3Rkb3V0LHN0ZGVycjplLnN0ZGVycn0pfSkpKX19LHtrZXk6XCJzdGRvdXRcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5fc3Rkb3V0fHxjb25zb2xlLl9zdGRvdXR9fSx7a2V5Olwic3RkZXJyXCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX3N0ZGVycnx8Y29uc29sZS5fc3RkZXJyfX1dKSxlfSgpO2QucHJvdG90eXBlLmFkZD1kLnByb3RvdHlwZS5hZGRSZXBvcnRlcixkLnByb3RvdHlwZS5yZW1vdmU9ZC5wcm90b3R5cGUucmVtb3ZlUmVwb3J0ZXIsZC5wcm90b3R5cGUuY2xlYXI9ZC5wcm90b3R5cGUucmVtb3ZlUmVwb3J0ZXIsZC5wcm90b3R5cGUud2l0aFNjb3BlPWQucHJvdG90eXBlLndpdGhUYWcsZC5wcm90b3R5cGUubW9jaz1kLnByb3RvdHlwZS5tb2NrVHlwZXMsZC5wcm90b3R5cGUucGF1c2U9ZC5wcm90b3R5cGUucGF1c2VMb2dzLGQucHJvdG90eXBlLnJlc3VtZT1kLnByb3RvdHlwZS5yZXN1bWVMb2dzO3ZhciB2LGc9ZnVuY3Rpb24oKXtmdW5jdGlvbiBlKHIpe3QodGhpcyxlKSx0aGlzLm9wdGlvbnM9T2JqZWN0LmFzc2lnbih7fSxyKSx0aGlzLmRlZmF1bHRDb2xvcj1cIiM3ZjhjOGRcIix0aGlzLmxldmVsQ29sb3JNYXA9ezA6XCIjYzAzOTJiXCIsMTpcIiNmMzljMTJcIiwzOlwiIzAwQkNENFwifSx0aGlzLnR5cGVDb2xvck1hcD17c3VjY2VzczpcIiMyZWNjNzFcIn19cmV0dXJuIHIoZSxbe2tleTpcImxvZ1wiLHZhbHVlOmZ1bmN0aW9uKHQpe3ZhciBlPXQubGV2ZWw8MT9jb25zb2xlLl9fZXJyb3J8fGNvbnNvbGUuZXJyb3I6MT09PXQubGV2ZWwmJmNvbnNvbGUud2Fybj9jb25zb2xlLl9fd2Fybnx8Y29uc29sZS53YXJuOmNvbnNvbGUuX19sb2d8fGNvbnNvbGUubG9nLHI9XCJsb2dcIiE9PXQudHlwZT90LnR5cGU6XCJcIixvPXQudGFnP3QudGFnOlwiXCIsbj10aGlzLnR5cGVDb2xvck1hcFt0LnR5cGVdfHx0aGlzLmxldmVsQ29sb3JNYXBbdC5sZXZlbF18fHRoaXMuZGVmYXVsdENvbG9yLHM9XCJcXG4gICAgICBiYWNrZ3JvdW5kOiBcIi5jb25jYXQobixcIjtcXG4gICAgICBib3JkZXItcmFkaXVzOiAwLjVlbTtcXG4gICAgICBjb2xvcjogd2hpdGU7XFxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxuICAgICAgcGFkZGluZzogMnB4IDAuNWVtO1xcbiAgICBcIiksYT1cIiVjXCIuY29uY2F0KFtvLHJdLmZpbHRlcihCb29sZWFuKS5qb2luKFwiOlwiKSk7XCJzdHJpbmdcIj09dHlwZW9mIHQuYXJnc1swXT9lLmFwcGx5KHZvaWQgMCxbXCJcIi5jb25jYXQoYSxcIiVjIFwiKS5jb25jYXQodC5hcmdzWzBdKSxzLFwiXCJdLmNvbmNhdChpKHQuYXJncy5zbGljZSgxKSkpKTplLmFwcGx5KHZvaWQgMCxbYSxzXS5jb25jYXQoaSh0LmFyZ3MpKSl9fV0pLGV9KCk7cmV0dXJuXCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdyYmd2luZG93LmNvbnNvbGF8fCgodj1uZXcgZCh7cmVwb3J0ZXJzOltuZXcgZ119KSkuQ29uc29sYT1kLHYuTG9nTGV2ZWw9Yyx2LkJyb3dzZXJSZXBvcnRlcj1nLHYpfSkpO1xuIiwiLy8gUkVHRVhcbmV4cG9ydCBjb25zdCBOVU1CRVJfUkVHRVggPSAvXFxkW1xcZFxccywuXSpcXGQrLztcbmV4cG9ydCBjb25zdCBDVVJSRU5DWV9SRUdFWCA9XG4gIC9bJFxceEEyLVxceEE1XFx1MDU4RlxcdTA2MEJcXHUwOUYyXFx1MDlGM1xcdTA5RkJcXHUwQUYxXFx1MEJGOVxcdTBFM0ZcXHUxN0RCXFx1MjBBMC1cXHUyMEJEXFx1QTgzOFxcdUZERkNcXHVGRTY5XFx1RkYwNFxcdUZGRTBcXHVGRkUxXFx1RkZFNVxcdUZGRTZdLztcbmV4cG9ydCBjb25zdCBIVE1MX1NQQUNFID0gLyhcXHN8Jm5ic3A7KT8vO1xuZXhwb3J0IGNvbnN0IFBSSUNFX1JFR0VYID0gYCgke0NVUlJFTkNZX1JFR0VYLnNvdXJjZX0ke0hUTUxfU1BBQ0Uuc291cmNlfSR7TlVNQkVSX1JFR0VYLnNvdXJjZX0pfCgke05VTUJFUl9SRUdFWC5zb3VyY2V9JHtIVE1MX1NQQUNFLnNvdXJjZX0ke0NVUlJFTkNZX1JFR0VYLnNvdXJjZX0pYDtcblxuLy8gUm91dGVzXG5leHBvcnQgY29uc3QgQklOQU5DRV9BUElfUk9VVEUgPSBcImh0dHBzOi8vYXBpLmJpbmFuY2UuY29tL2FwaS92My90aWNrZXIvcHJpY2VcIjtcblxuLy8gQWxhcm1zXG5leHBvcnQgY29uc3QgQUxBUk0gPSB7XG4gIGZldGNoQXZnUHJpY2U6IFwiZmV0Y2hBdmdQcmljZVwiLFxufTtcbiIsImltcG9ydCB7IEJJTkFOQ0VfQVBJX1JPVVRFIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5cbmNvbnN0IHBhcnNlTnVtYmVyID0gKHRleHRDb250ZW50KSA9PiB7XG4gIGNvbnN0IHBhcnRzID0gdGV4dENvbnRlbnQucmVwbGFjZSgvW1xccyxdL2csIFwiLlwiKS5zcGxpdChcIi5cIik7XG4gIGlmIChwYXJ0cy5sZW5ndGggPT09IDEpIHtcbiAgICByZXR1cm4gcGFyc2VGbG9hdChwYXJ0c1swXSk7XG4gIH1cbiAgbGV0IGRlY2ltYWxzID0gcGFydHMucG9wKCk7XG4gIGlmIChkZWNpbWFscy5sZW5ndGggPT09IDMpIHtcbiAgICBwYXJ0cy5wdXNoKGRlY2ltYWxzKTtcbiAgICBkZWNpbWFscyA9IFwiMFwiO1xuICB9XG4gIHJldHVybiBwYXJzZUZsb2F0KGAke3BhcnRzLmpvaW4oXCJcIil9LiR7ZGVjaW1hbHN9YCk7XG59O1xuXG5jb25zdCBmZXRjaFByaWNlcyA9IGFzeW5jICgpID0+IHtcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChCSU5BTkNFX0FQSV9ST1VURSk7XG4gIGNvbnN0IHByaWNlcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgcmV0dXJuIHByaWNlcy5yZWR1Y2UoXG4gICAgLy8gU2VlOiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvNDQzMjUxMjQvNDQ0NDU0NlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1yZXR1cm4tYXNzaWduLG5vLXBhcmFtLXJlYXNzaWduLG5vLXNlcXVlbmNlc1xuICAgIChvYmosIGl0ZW0pID0+ICgob2JqW2l0ZW0uc3ltYm9sXSA9IHBhcnNlRmxvYXQoaXRlbS5wcmljZSkpLCBvYmopLFxuICAgIHt9XG4gICk7XG59O1xuXG5leHBvcnQgeyBwYXJzZU51bWJlciwgZmV0Y2hQcmljZXMgfTtcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgY29uc29sYSBmcm9tIFwiY29uc29sYVwiO1xuaW1wb3J0IHsgQUxBUk0gfSBmcm9tIFwiLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IGZldGNoUHJpY2VzIH0gZnJvbSBcIi4vdXRpbHNcIjtcblxuLy8gY2hyb21lIEFQSXNcbmFzeW5jIGZ1bmN0aW9uIGZldGNoQXZnUHJpY2UoKSB7XG4gIGNvbnN0IHByaWNlcyA9IGF3YWl0IGZldGNoUHJpY2VzKCk7XG4gIGNvbnN0IHsgQlRDVVNEVDogcmF0ZSB9ID0gcHJpY2VzO1xuICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7IEJUQ1VTRFQ6IHJhdGUgfSwgKCkgPT4ge1xuICAgIGNvbnNvbGEubG9nKFwiUmF0ZXMgdXBkYXRlZFwiKTtcbiAgfSk7XG59XG5cbmNocm9tZS5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcihhc3luYyAoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09IEFMQVJNLmZldGNoQXZnUHJpY2UpIHtcbiAgICBhd2FpdCBmZXRjaEF2Z1ByaWNlKCk7XG4gIH1cbn0pO1xuXG5jaHJvbWUucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGZldGNoQXZnUHJpY2UoKTtcbiAgY2hyb21lLmFsYXJtcy5jcmVhdGUoQUxBUk0uZmV0Y2hBdmdQcmljZSwgeyBwZXJpb2RJbk1pbnV0ZXM6IDEgfSk7XG59KTtcblxuY2hyb21lLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKCh0YWJJZCkgPT4ge1xuICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwgXCJyZWZyZXNoUHJpY2VzXCIpO1xufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=