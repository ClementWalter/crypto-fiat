/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NUMBER_REGEX": () => (/* binding */ NUMBER_REGEX),
/* harmony export */   "CURRENCY_REGEX": () => (/* binding */ CURRENCY_REGEX),
/* harmony export */   "HTML_SPACE": () => (/* binding */ HTML_SPACE),
/* harmony export */   "PRICE_REGEX": () => (/* binding */ PRICE_REGEX),
/* harmony export */   "BINANCE_API_ROUTE": () => (/* binding */ BINANCE_API_ROUTE),
/* harmony export */   "ALARM": () => (/* binding */ ALARM)
/* harmony export */ });
// REGEX
const NUMBER_REGEX = /\d[\d\s,.]*\d+/;
const CURRENCY_REGEX =
  /[$\xA2-\xA5\u058F\u060B\u09F2\u09F3\u09FB\u0AF1\u0BF9\u0E3F\u17DB\u20A0-\u20BD\uA838\uFDFC\uFE69\uFF04\uFFE0\uFFE1\uFFE5\uFFE6]/;
const HTML_SPACE = /(\s|&nbsp;)?/;
const PRICE_REGEX = `(${CURRENCY_REGEX.source}${HTML_SPACE.source}${NUMBER_REGEX.source})|(${NUMBER_REGEX.source}${HTML_SPACE.source}${CURRENCY_REGEX.source})`;

// Routes
const BINANCE_API_ROUTE = "https://api.binance.com/api/v3/ticker/price";

// Alarms
const ALARM = {
  fetchAvgPrice: "fetchAvgPrice",
};


/***/ }),

/***/ "./src/utils.js":
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseNumber": () => (/* binding */ parseNumber),
/* harmony export */   "fetchPrices": () => (/* binding */ fetchPrices)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./src/constants.js");


const parseNumber = (textContent) => {
  const parts = textContent.replace(/[\s,]/g, ".").split(".");
  if (parts.length === 1) {
    return parseFloat(parts[0]);
  }
  let decimals = parts.pop();
  if (decimals.length === 3) {
    parts.push(decimals);
    decimals = "0";
  }
  return parseFloat(`${parts.join("")}.${decimals}`);
};

const fetchPrices = async () => {
  const response = await fetch(_constants__WEBPACK_IMPORTED_MODULE_0__.BINANCE_API_ROUTE);
  const prices = await response.json();
  return prices.reduce(
    // See: https://stackoverflow.com/a/44325124/4444546
    // eslint-disable-next-line no-return-assign,no-param-reassign,no-sequences
    (obj, item) => ((obj[item.symbol] = parseFloat(item.price)), obj),
    {}
  );
};




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./src/constants.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/utils.js");



// utils
const updateContent = (rate) => (textContent) =>
  Array.from(textContent.matchAll(_constants__WEBPACK_IMPORTED_MODULE_0__.PRICE_REGEX))
    .map((price) => [
      price[0],
      `${(0,_utils__WEBPACK_IMPORTED_MODULE_1__.parseNumber)(price[0].match(_constants__WEBPACK_IMPORTED_MODULE_0__.NUMBER_REGEX)[0]) / rate.BTCUSDT} BTC`,
    ])
    .reduce(
      (previousValue, currentValue) =>
        previousValue.replace(currentValue[0], currentValue[1]),
      textContent
    );

const updateDOM = (rate) => {
  const allElements = document.getElementsByTagName("*");
  for (let i = 0; i < allElements.length; i += 1) {
    const element = allElements[i];
    // eslint-disable-next-line no-restricted-syntax
    for (const node of Array.from(element.childNodes)) {
      if (node.nodeType === node.TEXT_NODE) {
        const newContent = updateContent(rate)(node.textContent);
        if (node.textContent !== newContent) {
          node.textContent = newContent;
        }
      }
    }
  }
};

function updatePrice() {
  for (let second = 0; second < 3; second += 1) {
    window.setTimeout(
      () => chrome.storage.sync.get("BTCUSDT", updateDOM),
      1000 * second
    );
  }
}

window.onload = updatePrice;

// chrome APIs
chrome.runtime.onMessage.addListener((request) => {
  if (request === "refreshPrices") {
    updatePrice();
  }
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDTztBQUNBO0FBQ1A7QUFDTyw4QkFBOEI7QUFDOUIsd0JBQXdCLHNCQUFzQixFQUFFLGtCQUFrQixFQUFFLG9CQUFvQixLQUFLLG9CQUFvQixFQUFFLGtCQUFrQixFQUFFLHNCQUFzQjs7QUFFcEs7QUFDTzs7QUFFUDtBQUNPO0FBQ1A7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNiZ0Q7O0FBRWhEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGVBQWUsR0FBRyxTQUFTO0FBQ2xEOztBQUVBO0FBQ0EsK0JBQStCLHlEQUFpQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVvQzs7Ozs7OztVQzFCcEM7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0Q7Ozs7Ozs7Ozs7Ozs7QUNOd0Q7QUFDbEI7O0FBRXRDO0FBQ0E7QUFDQSxrQ0FBa0MsbURBQVc7QUFDN0M7QUFDQTtBQUNBLFNBQVMsbURBQVcsZ0JBQWdCLG9EQUFZLHNCQUFzQjtBQUN0RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGtCQUFrQix3QkFBd0I7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsdUJBQXVCLFlBQVk7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY3J5cHRvLWZpYXQvLi9zcmMvY29uc3RhbnRzLmpzIiwid2VicGFjazovL2NyeXB0by1maWF0Ly4vc3JjL3V0aWxzLmpzIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9jcnlwdG8tZmlhdC93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2NyeXB0by1maWF0L3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vY3J5cHRvLWZpYXQvLi9zcmMvY29udGVudC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSRUdFWFxuZXhwb3J0IGNvbnN0IE5VTUJFUl9SRUdFWCA9IC9cXGRbXFxkXFxzLC5dKlxcZCsvO1xuZXhwb3J0IGNvbnN0IENVUlJFTkNZX1JFR0VYID1cbiAgL1skXFx4QTItXFx4QTVcXHUwNThGXFx1MDYwQlxcdTA5RjJcXHUwOUYzXFx1MDlGQlxcdTBBRjFcXHUwQkY5XFx1MEUzRlxcdTE3REJcXHUyMEEwLVxcdTIwQkRcXHVBODM4XFx1RkRGQ1xcdUZFNjlcXHVGRjA0XFx1RkZFMFxcdUZGRTFcXHVGRkU1XFx1RkZFNl0vO1xuZXhwb3J0IGNvbnN0IEhUTUxfU1BBQ0UgPSAvKFxcc3wmbmJzcDspPy87XG5leHBvcnQgY29uc3QgUFJJQ0VfUkVHRVggPSBgKCR7Q1VSUkVOQ1lfUkVHRVguc291cmNlfSR7SFRNTF9TUEFDRS5zb3VyY2V9JHtOVU1CRVJfUkVHRVguc291cmNlfSl8KCR7TlVNQkVSX1JFR0VYLnNvdXJjZX0ke0hUTUxfU1BBQ0Uuc291cmNlfSR7Q1VSUkVOQ1lfUkVHRVguc291cmNlfSlgO1xuXG4vLyBSb3V0ZXNcbmV4cG9ydCBjb25zdCBCSU5BTkNFX0FQSV9ST1VURSA9IFwiaHR0cHM6Ly9hcGkuYmluYW5jZS5jb20vYXBpL3YzL3RpY2tlci9wcmljZVwiO1xuXG4vLyBBbGFybXNcbmV4cG9ydCBjb25zdCBBTEFSTSA9IHtcbiAgZmV0Y2hBdmdQcmljZTogXCJmZXRjaEF2Z1ByaWNlXCIsXG59O1xuIiwiaW1wb3J0IHsgQklOQU5DRV9BUElfUk9VVEUgfSBmcm9tIFwiLi9jb25zdGFudHNcIjtcblxuY29uc3QgcGFyc2VOdW1iZXIgPSAodGV4dENvbnRlbnQpID0+IHtcbiAgY29uc3QgcGFydHMgPSB0ZXh0Q29udGVudC5yZXBsYWNlKC9bXFxzLF0vZywgXCIuXCIpLnNwbGl0KFwiLlwiKTtcbiAgaWYgKHBhcnRzLmxlbmd0aCA9PT0gMSkge1xuICAgIHJldHVybiBwYXJzZUZsb2F0KHBhcnRzWzBdKTtcbiAgfVxuICBsZXQgZGVjaW1hbHMgPSBwYXJ0cy5wb3AoKTtcbiAgaWYgKGRlY2ltYWxzLmxlbmd0aCA9PT0gMykge1xuICAgIHBhcnRzLnB1c2goZGVjaW1hbHMpO1xuICAgIGRlY2ltYWxzID0gXCIwXCI7XG4gIH1cbiAgcmV0dXJuIHBhcnNlRmxvYXQoYCR7cGFydHMuam9pbihcIlwiKX0uJHtkZWNpbWFsc31gKTtcbn07XG5cbmNvbnN0IGZldGNoUHJpY2VzID0gYXN5bmMgKCkgPT4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKEJJTkFOQ0VfQVBJX1JPVVRFKTtcbiAgY29uc3QgcHJpY2VzID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICByZXR1cm4gcHJpY2VzLnJlZHVjZShcbiAgICAvLyBTZWU6IGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS80NDMyNTEyNC80NDQ0NTQ2XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJldHVybi1hc3NpZ24sbm8tcGFyYW0tcmVhc3NpZ24sbm8tc2VxdWVuY2VzXG4gICAgKG9iaiwgaXRlbSkgPT4gKChvYmpbaXRlbS5zeW1ib2xdID0gcGFyc2VGbG9hdChpdGVtLnByaWNlKSksIG9iaiksXG4gICAge31cbiAgKTtcbn07XG5cbmV4cG9ydCB7IHBhcnNlTnVtYmVyLCBmZXRjaFByaWNlcyB9O1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgeyBQUklDRV9SRUdFWCwgTlVNQkVSX1JFR0VYIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5pbXBvcnQgeyBwYXJzZU51bWJlciB9IGZyb20gXCIuL3V0aWxzXCI7XG5cbi8vIHV0aWxzXG5jb25zdCB1cGRhdGVDb250ZW50ID0gKHJhdGUpID0+ICh0ZXh0Q29udGVudCkgPT5cbiAgQXJyYXkuZnJvbSh0ZXh0Q29udGVudC5tYXRjaEFsbChQUklDRV9SRUdFWCkpXG4gICAgLm1hcCgocHJpY2UpID0+IFtcbiAgICAgIHByaWNlWzBdLFxuICAgICAgYCR7cGFyc2VOdW1iZXIocHJpY2VbMF0ubWF0Y2goTlVNQkVSX1JFR0VYKVswXSkgLyByYXRlLkJUQ1VTRFR9IEJUQ2AsXG4gICAgXSlcbiAgICAucmVkdWNlKFxuICAgICAgKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSkgPT5cbiAgICAgICAgcHJldmlvdXNWYWx1ZS5yZXBsYWNlKGN1cnJlbnRWYWx1ZVswXSwgY3VycmVudFZhbHVlWzFdKSxcbiAgICAgIHRleHRDb250ZW50XG4gICAgKTtcblxuY29uc3QgdXBkYXRlRE9NID0gKHJhdGUpID0+IHtcbiAgY29uc3QgYWxsRWxlbWVudHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcIipcIik7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYWxsRWxlbWVudHMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICBjb25zdCBlbGVtZW50ID0gYWxsRWxlbWVudHNbaV07XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4XG4gICAgZm9yIChjb25zdCBub2RlIG9mIEFycmF5LmZyb20oZWxlbWVudC5jaGlsZE5vZGVzKSkge1xuICAgICAgaWYgKG5vZGUubm9kZVR5cGUgPT09IG5vZGUuVEVYVF9OT0RFKSB7XG4gICAgICAgIGNvbnN0IG5ld0NvbnRlbnQgPSB1cGRhdGVDb250ZW50KHJhdGUpKG5vZGUudGV4dENvbnRlbnQpO1xuICAgICAgICBpZiAobm9kZS50ZXh0Q29udGVudCAhPT0gbmV3Q29udGVudCkge1xuICAgICAgICAgIG5vZGUudGV4dENvbnRlbnQgPSBuZXdDb250ZW50O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuXG5mdW5jdGlvbiB1cGRhdGVQcmljZSgpIHtcbiAgZm9yIChsZXQgc2Vjb25kID0gMDsgc2Vjb25kIDwgMzsgc2Vjb25kICs9IDEpIHtcbiAgICB3aW5kb3cuc2V0VGltZW91dChcbiAgICAgICgpID0+IGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwiQlRDVVNEVFwiLCB1cGRhdGVET00pLFxuICAgICAgMTAwMCAqIHNlY29uZFxuICAgICk7XG4gIH1cbn1cblxud2luZG93Lm9ubG9hZCA9IHVwZGF0ZVByaWNlO1xuXG4vLyBjaHJvbWUgQVBJc1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXF1ZXN0KSA9PiB7XG4gIGlmIChyZXF1ZXN0ID09PSBcInJlZnJlc2hQcmljZXNcIikge1xuICAgIHVwZGF0ZVByaWNlKCk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9